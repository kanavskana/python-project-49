### Hexlet tests and linter status:
[![Actions Status](https://github.com/kanavskana/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/kanavskana/python-project-49/actions)

### 1 game: Brain Even
[![asciicast](https://asciinema.org/a/aDcZy2Z9FPMLdvyE6VJZtXEkX.svg)](https://asciinema.org/a/aDcZy2Z9FPMLdvyE6VJZtXEkX)

### 2 game: Brain Calc
[![asciicast](https://asciinema.org/a/wW9C1LzVioOT23iCo5Ph5TIXs.svg)](https://asciinema.org/a/wW9C1LzVioOT23iCo5Ph5TIXs)

### 3 game: Brain GCD
[![sciicast](https://asciinema.org/a/dvHADELC3URHvkE59LyZtaxcg.svg)](https://asciinema.org/a/dvHADELC3URHvkE59LyZtaxcg)

### 4 game: Brain Progression
[![asciicast](https://asciinema.org/a/nheRgGup5431xlFs2n3eJkSXF.svg)](https://asciinema.org/a/nheRgGup5431xlFs2n3eJkSXF)