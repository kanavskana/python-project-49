### Hexlet tests and linter status:
[![Actions Status](https://github.com/kanavskana/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/kanavskana/python-project-49/actions)

### 1st game: Brain Even
[![asciicast](https://asciinema.org/a/aDcZy2Z9FPMLdvyE6VJZtXEkX.svg)](https://asciinema.org/a/aDcZy2Z9FPMLdvyE6VJZtXEkX)
